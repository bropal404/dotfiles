#!/usr/bin/env fish

# Parse arguments
set action $argv[1]

# Move workspace based on argument
switch $action
    case -l
        # Move to laptop monitor
        hyprctl dispatch movecurrentworkspacetomonitor eDP-1
    case -m
        # Move to external monitor
        hyprctl dispatch movecurrentworkspacetomonitor DP-1
    case ''
        # No action, just rename
end

# Get all workspaces and rename them
set workspaces (hyprctl workspaces -j | jq -c '.[]')

for ws in $workspaces
    set ws_id (echo $ws | jq -r '.id')
    set monitor (echo $ws | jq -r '.monitor')

    # Set prefix based on monitor name
    if string match -q "*eDP*" $monitor
        set prefix L
    else
        set prefix M
    end

    # Rename workspace
    hyprctl dispatch renameworkspace $ws_id "$prefix$ws_id"
end
