#!/bin/bash

LIGHT="$HOME/Pictures/wall/light.jpg"
DARK="$HOME/Pictures/wall/dark.jpg"
STATE="$HOME/.cache/hypr-wallpaper"

if [ ! -f "$STATE" ] || [ "$(cat "$STATE")" = "dark" ]; then
    pkill swaybg
    swaybg -i "$LIGHT" -m fill &
    echo "light" > "$STATE"
else
    pkill swaybg
    swaybg -i "$DARK" -m fill &
    echo "dark" > "$STATE"
fi

