#!/bin/sh

pgrep hypridle > /dev/null && notify-send "Screen sleep / locking off" && killall hypridle || (notify-send "Screen sleep / locking on" && hypridle &)

